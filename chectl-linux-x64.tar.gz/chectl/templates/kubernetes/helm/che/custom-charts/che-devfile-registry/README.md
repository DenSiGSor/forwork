# Che devfile Registry Helm Chart

This Helm Chart install [Che](https://github.com/eclipse/che) devfile Registry. More information about Che devfile Registry can be found [here](https://github.com/eclipse/che-devfile-registry).