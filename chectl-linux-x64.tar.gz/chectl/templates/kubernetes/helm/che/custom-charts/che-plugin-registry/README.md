# Che Plugin Registry Helm Chart

This Helm Chart install [Che](https://github.com/eclipse/che) Plugin Registry. More information about Che Plugin Registry can be found [here](https://github.com/eclipse/che-plugin-registry).