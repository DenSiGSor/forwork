Deployment instructions for [Single User](https://www.eclipse.org/che/docs/kubernetes-single-user.html) and [Multi User](https://www.eclipse.org/che/docs/kubernetes-multi-user.html) Che.
