/*********************************************************************
 * Copyright (c) 2019 Red Hat, Inc.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 **********************************************************************/
import { KubeConfig } from '@kubernetes/client-node';
export declare class CheHelper {
    defaultCheResponseTimeoutMs: number;
    kc: KubeConfig;
    cheServerPodExist(namespace: string): Promise<boolean>;
    /**
     * Finds a pod where Che workspace is running.
     * Rejects if no workspace is found for the given workspace ID
     * or if workspace ID wasn't specified but more than one workspace is found.
     */
    getWorkspacePod(namespace: string, cheWorkspaceId?: string): Promise<string>;
    getWorkspacePodContainers(namespace: string, cheWorkspaceId?: string): Promise<string[]>;
    cheURL(namespace?: string): Promise<string>;
    cheK8sURL(namespace?: string): Promise<string>;
    cheOpenShiftURL(namespace?: string): Promise<string>;
    cheNamespaceExist(namespace?: string): Promise<boolean>;
    getCheServerStatus(cheURL: string, responseTimeoutMs?: number): Promise<string>;
    startShutdown(cheURL: string, accessToken?: string, responseTimeoutMs?: number): Promise<void>;
    waitUntilReadyToShutdown(cheURL: string, intervalMs?: number, timeoutMs?: number): Promise<void>;
    isCheServerReady(cheURL: string, namespace?: string, responseTimeoutMs?: number): Promise<boolean>;
    createWorkspaceFromDevfile(namespace: string | undefined, devfilePath: string | undefined, workspaceName: string | undefined, accessToken?: string): Promise<string>;
    parseDevfile(devfilePath?: string): Promise<string>;
    createWorkspaceFromWorkspaceConfig(namespace: string | undefined, workspaceConfigPath?: string, accessToken?: string): Promise<string>;
    isAuthenticationEnabled(cheURL: string, responseTimeoutMs?: number): Promise<boolean>;
    buildDashboardURL(ideURL: string): Promise<string>;
    private getCheApiError;
}
