/*********************************************************************
 * Copyright (c) 2019 Red Hat, Inc.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 **********************************************************************/
import { Command } from '@oclif/command';
export default class Start extends Command {
    static description: string;
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        chenamespace: import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;
        devfile: import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;
        workspaceconfig: import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;
        name: import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;
        'access-token': import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;
        'listr-renderer': import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;
    };
    checkToken(flags: any, ctx: any): Promise<void>;
    run(): Promise<void>;
}
