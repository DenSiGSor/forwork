/*********************************************************************
 * Copyright (c) 2019 Red Hat, Inc.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 **********************************************************************/
import { Command } from '@oclif/command';
import * as Listr from 'listr';
export declare class HelmHelper {
    startTasks(flags: any, command: Command): Listr;
    tillerRoleBindingExist(execTimeout?: number): Promise<boolean>;
    createTillerRoleBinding(execTimeout?: number): Promise<void>;
    tillerServiceAccountExist(execTimeout?: number): Promise<boolean>;
    createTillerServiceAccount(execTimeout?: number): Promise<void>;
    createTillerRBAC(templatesPath: any, execTimeout?: number): Promise<void>;
    tillerServiceExist(execTimeout?: number): Promise<boolean>;
    createTillerService(execTimeout?: number): Promise<void>;
    prepareCheHelmChart(flags: any, cacheDir: string): Promise<void>;
    updateCheHelmChartDependencies(cacheDir: string, execTimeout?: number): Promise<void>;
    upgradeCheHelmChart(_ctx: any, flags: any, cacheDir: string, execTimeout?: number): Promise<void>;
    purgeHelmChart(name: string, execTimeout?: number): Promise<void>;
}
